-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 26, 2020 at 10:29 AM
-- Server version: 5.7.29-0ubuntu0.16.04.1
-- PHP Version: 7.2.28-3+ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `se62_06`
--

-- --------------------------------------------------------

--
-- Table structure for table `catagory`
--

CREATE TABLE `catagory` (
  `OT_ID` varchar(4) NOT NULL,
  `OT_Name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catagory`
--

INSERT INTO `catagory` (`OT_ID`, `OT_Name`) VALUES
('T001', 'เครื่องคอมพิวเตอร์'),
('T002', 'อุปกรณ์อิเล็คทรอนิค'),
('T003', 'อุปกรณ์ตกแต่ง');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `rent_ID` varchar(10) NOT NULL,
  `startDate` date NOT NULL,
  `endDate` date DEFAULT NULL,
  `statusHistory` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`rent_ID`, `startDate`, `endDate`, `statusHistory`) VALUES
('R001', '2020-03-15', '2020-03-22', 'HS01');

-- --------------------------------------------------------

--
-- Table structure for table `history_status`
--

CREATE TABLE `history_status` (
  `HS_ID` varchar(4) NOT NULL,
  `statusName` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `history_status`
--

INSERT INTO `history_status` (`HS_ID`, `statusName`) VALUES
('HS01', 'ยืมอยู่'),
('HS02', 'คืนแล้ว');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `uid` varchar(11) CHARACTER SET utf8 NOT NULL,
  `kuID` varchar(11) CHARACTER SET utf8 NOT NULL,
  `prename` varchar(10) CHARACTER SET utf8 NOT NULL,
  `firstname` varchar(50) CHARACTER SET utf8 NOT NULL,
  `lastname` varchar(50) CHARACTER SET utf8 NOT NULL,
  `types` varchar(1) CHARACTER SET utf8 NOT NULL,
  `email` varchar(70) CHARACTER SET utf8 NOT NULL,
  `USERROLES` set('ADMIN','MANAGER','USER') DEFAULT 'USER'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`uid`, `kuID`, `prename`, `firstname`, `lastname`, `types`, `email`, `USERROLES`) VALUES
('b6020500390', '6020500390', 'นาย', 'สุรเชษฐ', 'แสงน้อย', '3', 'surachet.sang@ku.th', 'USER'),
('b6020502058', '6020502058', 'นาย', 'ชนายุทธ', 'ภาราทอง', '3', 'chanayut.p@ku.th', 'USER'),
('b6020503844', '6020503844', 'นางสาว', 'ผกายมาส', 'บุญวิทยา', '3', 'pakaymas.b@ku.th', 'ADMIN'),
('b6020503879', '6020503879', 'นาย', 'ภาสวิชญ์', 'ชมทิพย์', '3', 'phassawich.c@ku.th', 'ADMIN'),
('fengncn', 'fengncn', 'อาจารย์', 'นุชนาฎ', 'สัตยากวี', '3', 'fengncn@ku.th', 'MANAGER'),
('fengsstc', 'fengsstc', 'พี่', 'แก้ว', ' ', '3', 'fengncn@ku.th', 'ADMIN');

-- --------------------------------------------------------

--
-- Table structure for table `rent`
--

CREATE TABLE `rent` (
  `R_ID` varchar(4) NOT NULL,
  `R_Date` date NOT NULL,
  `Person` varchar(15) NOT NULL,
  `Responsible` varchar(15) NOT NULL,
  `commit` varchar(1) NOT NULL DEFAULT 'w'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rent`
--

INSERT INTO `rent` (`R_ID`, `R_Date`, `Person`, `Responsible`, `commit`) VALUES
('R001', '2018-07-11', 'b6020503844', 'b6020503844', 'Y'),
('R002', '2018-07-15', 'b6020500390', 'b6020503879', 'W');

-- --------------------------------------------------------

--
-- Table structure for table `rent_detail`
--

CREATE TABLE `rent_detail` (
  `R_ID` varchar(10) NOT NULL,
  `OID` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rent_detail`
--

INSERT INTO `rent_detail` (`R_ID`, `OID`) VALUES
('R001', 'O0001'),
('R001', 'O0002');

-- --------------------------------------------------------

--
-- Table structure for table `rent_status`
--

CREATE TABLE `rent_status` (
  `RS_ID` varchar(2) NOT NULL,
  `RS_Type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rent_status`
--

INSERT INTO `rent_status` (`RS_ID`, `RS_Type`) VALUES
('C', 'เลยเวลารับของ'),
('N', 'ไม่อนุมัติ'),
('W', 'รออนุมัติ'),
('Y', 'อนุมัติ');

-- --------------------------------------------------------

--
-- Table structure for table `status_detail`
--

CREATE TABLE `status_detail` (
  `commitDate` date NOT NULL,
  `R_ID` varchar(6) NOT NULL,
  `Reason` varchar(500) CHARACTER SET utf8 DEFAULT '-'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status_detail`
--

INSERT INTO `status_detail` (`commitDate`, `R_ID`, `Reason`) VALUES
('2020-03-09', 'R001', '-'),
('2020-03-10', 'R002', 'มสวมวสมวสมว');

-- --------------------------------------------------------

--
-- Table structure for table `tools`
--

CREATE TABLE `tools` (
  `OID` varchar(5) NOT NULL,
  `Oname` varchar(40) NOT NULL,
  `detail` text NOT NULL,
  `serial` varchar(20) NOT NULL,
  `objType` varchar(4) NOT NULL,
  `objStatus` varchar(4) NOT NULL,
  `Permited` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tools`
--

INSERT INTO `tools` (`OID`, `Oname`, `detail`, `serial`, `objType`, `objStatus`, `Permited`) VALUES
('O0001', 'จอ LCD 23 นิ้ว', 'บลาๆ', '02/04-001/2562', 'T001', 'OS1', 'OP01'),
('O0002', 'เมาส์ไร้สาย', 'เสียบหัว USB Type-A ที่คอมพิวเตอร์ จากนั้นคลิ๊กซ้ายหนึ่งครั้ง จึงสามารถใช้งานได้', '02/04-002/2562', 'T001', 'OS1', 'OP02'),
('O0003', 'กรรไกร', 'ตัดกระดาษ', '02/04-003/2562', 'T002', 'OS1', 'OP01');

-- --------------------------------------------------------

--
-- Table structure for table `tools_permitted`
--

CREATE TABLE `tools_permitted` (
  `OP_ID` varchar(4) NOT NULL,
  `position` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tools_permitted`
--

INSERT INTO `tools_permitted` (`OP_ID`, `position`) VALUES
('OP01', 'All'),
('OP02', 'Staff');

-- --------------------------------------------------------

--
-- Table structure for table `tools_status`
--

CREATE TABLE `tools_status` (
  `OS_ID` varchar(3) NOT NULL,
  `OSStatus` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tools_status`
--

INSERT INTO `tools_status` (`OS_ID`, `OSStatus`) VALUES
('OS1', 'ยืมได้'),
('OS2', 'ชำรุด'),
('OS3', 'ถูกยืม'),
('OS4', 'จอง'),
('OS5', 'หมด');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `catagory`
--
ALTER TABLE `catagory`
  ADD PRIMARY KEY (`OT_ID`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`rent_ID`,`startDate`);

--
-- Indexes for table `history_status`
--
ALTER TABLE `history_status`
  ADD PRIMARY KEY (`HS_ID`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `rent`
--
ALTER TABLE `rent`
  ADD PRIMARY KEY (`R_ID`);

--
-- Indexes for table `rent_detail`
--
ALTER TABLE `rent_detail`
  ADD PRIMARY KEY (`R_ID`,`OID`);

--
-- Indexes for table `rent_status`
--
ALTER TABLE `rent_status`
  ADD PRIMARY KEY (`RS_ID`);

--
-- Indexes for table `status_detail`
--
ALTER TABLE `status_detail`
  ADD PRIMARY KEY (`commitDate`,`R_ID`);

--
-- Indexes for table `tools`
--
ALTER TABLE `tools`
  ADD PRIMARY KEY (`OID`);

--
-- Indexes for table `tools_permitted`
--
ALTER TABLE `tools_permitted`
  ADD PRIMARY KEY (`OP_ID`);

--
-- Indexes for table `tools_status`
--
ALTER TABLE `tools_status`
  ADD PRIMARY KEY (`OS_ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
