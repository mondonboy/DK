<?php
class PromiseController{
    public function handleRequest(string $action="Promise", array $params) {
        switch ($action) {
            case "Promise":
                $this->promise();
                break;
            case "ChangePromise":
                $this->changepromise();
                break;
            case "Updatepromise":
                $this->updatepromise();
                break;
            default:
                break;
        }

    }
    private function promise(){
        session_start();
        if($_SESSION['member']->getUSERROLES()=="ADMIN"){
            include Router::getSourcePath() . "views/PromiseAdmin.php";
        }
        if($_SESSION['member']->getUSERROLES()=="MANAGER"){
            include Router::getSourcePath() . "views/Manager/PromiseManager.php";
        }
        if($_SESSION['member']->getUSERROLES()=="USER"){
            include Router::getSourcePath() . "views/User/PromiseUser.php";
        }
    }
    private function changepromise(){
        session_start();
        if($_SESSION['member']->getUSERROLES()=="ADMIN"){
            include Router::getSourcePath() . "views/ChangePromiseAdmin.php";
        }
    }
    private function updatepromise(){
        session_start();
        $role = $_POST['USERROLES'];
        $id = $_SESSION['uid'];
        //echo $id." ".$role;
        $m = Member::findByAccount($id);
        $m->setUSERROLES($role);
            //print_r($m);
        $m->update();
        if($_SESSION['member']->getUSERROLES()=="ADMIN"){
            include Router::getSourcePath() . "views/PromiseAdmin.php";
        }
    }
}

?>