<?php
/**
 * Created by PhpStorm.
 * User: Diiar
 * Date: 24/1/2562
 * Time: 14:51
 */

class ToolController
{
    public function handleRequest(string $action="index", array $params=null) {
        switch ($action)
        {
            case "index":
                $this->index();
                break;
            case "newItem":
                $this->newItem();
                break;
            case "addItem" :
                $this->addItem();
                break;
            case "update" :
                $this->updateForm();
            default:
                break;
        }

    }
    private function index()
    {
        include Router::getSourcePath()."views/RentAdmin.php";
    }
    private function newItem()
    {
        $_SESSION['catagory'] = Catagory::findAll();
        $_SESSION['permit'] = Permit::findAll();
        $_SESSION['tools_status'] = ToolStatus::findAll();
        include Router::getSourcePath()."views/AddItemAdmin.php";
    }
    private function addItem()
    {
        $result="";
        for ($a = 1; $a < 10; $a++) { // จำนวนรอบที่ต้องการทดสอบ หรือ สุ่ม
            $number = '0123456789'; // ตัวแปรตัวเลข ที่จะเอาไปสุ่ม
            //$number="ABCDEFGHIJKLMNOPQRSTUVWXYZ"; // ตัวแปรแบบตัวอักษรภาษาอังกฤษ ที่จะเอาไปสุ่ม

            for ($i = 1; $i <= 5; $i++) { // จำนวนหลักที่ต้องการสามารถเปลี่ยนได้ตามใจชอบนะครับ จาก 5 เป็น 3 หรือ 6 หรือ 10 เป็นต้น
                $random = rand(0, strlen($number) - 1); //สุ่มตัวเลข
                $cut_txt = substr($number, $random, 1); //ตัดตัวเลข หรือ ตัวอักษรจากตำแหน่งที่สุ่มได้มา 1 ตัว
                $result .= substr($number, $random, 1); // เก็บค่าที่ตัดมาแล้วใส่ตัวแปร
                $number = str_replace($cut_txt, '', $number); // ลบ หรือ แทนที่ตัวอักษร หรือ ตัวเลขนั้นด้วยค่า ว่าง
            }

            $i = 0; // ตั้งค่าให้ $i ใหม่ เริ่มต้นที่ 0
            echo $result . "<br>"; // แสดงค่าและขึ้นบรรทัดใหม่
            $result = ''; // ล้างค่าตัวแปรออก เพื่อรับค่าใหม่ในรอบต่อไป
        }
        $OID = $result;

        $type = $_POST['type'];
        $serial = $_POST['serial'];
        $name = $_POST['name'];
        $detail = $_POST['detail'];
        $permit = $_POST['permit'];
        $status  = $_POST['status'];
        $tool = new Tool($OID,$name,$detail,$serial,$type,$status,$permit);
        $tool->insert();
        include Router::getSourcePath()."views/CorrectToolAdmin.php";
    }

    private  function updateForm()
    {
        $O_ID = $_SESSION["tools"]->getOID();
        $tools = Tool::findByID($O_ID);
        $_SESSION['catagory'] = Catagory::findAll();
        $_SESSION['permit'] = Permit::findAll();
        $_SESSION['tools_status'] = ToolStatus::findAll();
        include Router::getSourcePath()."views/EditItemAdmin.php";
    }
}