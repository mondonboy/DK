<title>W3.CSS Template</title>
<style>
    body {font-family: "Lato", sans-serif}
    .mySlides {display: none}
    html,body,h1,h2,h3,h4,h5,h6 {font-family: "Roboto", sans-serif}
    body,h1 {font-family: "Montserrat", sans-serif}
    img {margin-bottom: -7px}
    .w3-row-padding img {margin-bottom: 12px}
</style>