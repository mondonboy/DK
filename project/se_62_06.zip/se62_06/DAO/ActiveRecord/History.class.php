<?php


class History
{
    private $rent_ID;
    private $startDate;
    private $endDate;
    private $statusHistory;
    private const TABLE = "history";

    /**
     * History constructor.
     * @param $rent_ID
     * @param $startDate
     * @param $endDate
     * @param $statusHistory
     */
    public function __construct($rent_ID, $startDate, $endDate = null, $statusHistory = "HS01")
    {
        $this->rent_ID = $rent_ID;
        $this->startDate = $startDate;
        $this->endDate = $endDate;
        $this->statusHistory = $statusHistory;
    }

    /**
     * @return mixed
     */
    public function getRentID()
    {
        return $this->rent_ID;
    }

    /**
     * @param mixed $rent_ID
     */
    public function setRentID($rent_ID): void
    {
        $this->rent_ID = $rent_ID;
    }

    /**
     * @return mixed
     */
    public function getStartDate()
    {
        return $this->startDate;
    }

    /**
     * @param mixed $startDate
     */
    public function setStartDate($startDate): void
    {
        $this->startDate = $startDate;
    }

    /**
     * @return null
     */
    public function getEndDate()
    {
        return $this->endDate;
    }

    /**
     * @param null $endDate
     */
    public function setEndDate($endDate): void
    {
        $this->endDate = $endDate;
    }

    /**
     * @return string
     */
    public function getStatusHistory(): string
    {
        return $this->statusHistory;
    }

    /**
     * @param string $statusHistory
     */
    public function setStatusHistory(string $statusHistory): void
    {
        $this->statusHistory = $statusHistory;
    }


    public static function findAll(): array {
        $con = Db::getInstance();
        $query = "SELECT * FROM ".self::TABLE;
        $stmt = $con->query($query);
        //$stmt->setFetchMode(PDO::FETCH_CLASS, "Member");
        //$stmt->execute();
        $memberList  = array();
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row)
        {
            $memberList[$row["rent_ID"]] = new History($row["rent_ID"],$row["startDate"],$row["endDate"],$row["statusHistory"]);
        }
        return $memberList;
    }

    public static function findByID(string $username): ?History {
        $con = Db::getInstance();
        $query = "SELECT * FROM ".self::TABLE." where rent_ID = '$username'";
        $stmt = $con->query($query);
        //$stmt->setFetchMode(PDO::FETCH_CLASS, "Member");
        //$stmt->execute();
        if ($memb = $stmt->fetch(PDO::FETCH_ASSOC))
        {
            $member = self::findAll();
            return $member[$memb['rent_ID']];
        }
        return null;
    }

    public function insert() {
        $con = Db::getInstance();
        $values = "";
        foreach ($this as $prop => $val) {
            $values .= "'$val',";
        }
        $values = substr($values,0,-1);
        $query = "INSERT INTO ".self::TABLE." VALUES ($values)";
        //echo $query;
        $res = $con->exec($query);
        //$this->uid = $con->lastInsertId();
        return $res;
    }

    public function update() {
        $query = "UPDATE ".self::TABLE." SET ";
        foreach ($this as $prop => $val) {
            $query .= " $prop='$val',";
        }
        $query = substr($query, 0, -1);
        $query .= " WHERE rent_ID = '".$this->getRentID()."'";
        $con = Db::getInstance();
        $res = $con->exec($query);
        return $res;
    }
}