<?php


class HistoryStatus
{
    private $HS_ID;
    private $statusName;
    private const TABLE = "history_status";

    /**
     * HistoryStatus constructor.
     * @param $HS_ID
     * @param $statusName
     */
    public function __construct($HS_ID, $statusName)
    {
        $this->HS_ID = $HS_ID;
        $this->statusName = $statusName;
    }

    /**
     * @return mixed
     */
    public function getHSID()
    {
        return $this->HS_ID;
    }

    /**
     * @param mixed $HS_ID
     */
    public function setHSID($HS_ID): void
    {
        $this->HS_ID = $HS_ID;
    }

    /**
     * @return mixed
     */
    public function getStatusName()
    {
        return $this->statusName;
    }

    /**
     * @param mixed $statusName
     */
    public function setStatusName($statusName): void
    {
        $this->statusName = $statusName;
    }

    public static function findAll(): array {
        $con = Db::getInstance();
        $query = "SELECT * FROM ".self::TABLE;
        $stmt = $con->query($query);
        //$stmt->setFetchMode(PDO::FETCH_CLASS, "Member");
        //$stmt->execute();
        $memberList  = array();
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row)
        {
            $memberList[$row["HS_ID"]] = new HistoryStatus($row["HS_ID"],$row["statusName"]);
        }
        return $memberList;
    }

    public static function findByID(string $username): ?History {
        $con = Db::getInstance();
        $query = "SELECT * FROM ".self::TABLE." where HS_ID = '$username'";
        $stmt = $con->query($query);
        //$stmt->setFetchMode(PDO::FETCH_CLASS, "Member");
        //$stmt->execute();
        if ($memb = $stmt->fetch(PDO::FETCH_ASSOC))
        {
            $member = self::findAll();
            return $member[$memb['HS_ID']];
        }
        return null;
    }

    public function insert() {
        $con = Db::getInstance();
        $values = "";
        foreach ($this as $prop => $val) {
            $values .= "'$val',";
        }
        $values = substr($values,0,-1);
        $query = "INSERT INTO ".self::TABLE." VALUES ($values)";
        //echo $query;
        $res = $con->exec($query);
        //$this->uid = $con->lastInsertId();
        return $res;
    }

    public function update() {
        $query = "UPDATE ".self::TABLE." SET ";
        foreach ($this as $prop => $val) {
            $query .= " $prop='$val',";
        }
        $query = substr($query, 0, -1);
        $query .= " WHERE HS_ID = '".$this->getHSID()."'";
        $con = Db::getInstance();
        $res = $con->exec($query);
        return $res;
    }


}