<?php


class Permitted
{
    
}